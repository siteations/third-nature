import React from 'react'
import ReactDOM from 'react-dom'
import Landing from './components/Landing.js'


ReactDOM.render(<Landing />, document.getElementById('app'));
